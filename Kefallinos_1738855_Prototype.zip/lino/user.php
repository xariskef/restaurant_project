<?php


// Initialize the session
session_start();
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
	header("location:error_404/index.html");
							exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
<!--===============================================================================================-->	
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/user.css">
	<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">
<!--===============================================================================================-->
</head>
<body class="animsition">
<?php
	include 'includes/header.php';
	include 'includes/sidebar.php';
?>


	<!-- Title Page -->
	<section class=" flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(images/bg-title-page-03.jpg);">
		
	</section>

<?php

 echo '
					<li id="login" class="t-center m-b-13"> 
					 <a href="user.php" class="txt10"><img src="fonts\ionicons-2.0.1\png\512\ios7-contact-outline.png" width="10%"><br>
					      This is your Profil page <b>'.$_SESSION['uid'].'</b></a>
						      <form action="login/includes/logout.inc.php" method="post">
                                <button type="submit" name="login-submit" class="btn3 flex-c-m size13 txt11 trans-0-4 m-l-r-auto">
								Logout</button>
                               </form> <br><br>';
		                
						
						
						//print_r($_SESSION);
						//include the email session into a variable
						$email=$_SESSION['email'];
						$name=$_SESSION['uid'];
						//echo $email;
						//Important to pass the variable int sql query
						$email=mysqli_real_escape_string($conn,$email);
						
					$sql = "SELECT * FROM reservation WHERE remail='$email';" ;
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
                   
				     $sqli = "SELECT COUNT(rid) AS value_sum FROM reservation WHERE remail='$email';";
                     $resulti = mysqli_query($conn, $sqli);
                     $resultChecki = mysqli_num_rows($resulti);
	                 $rowi= mysqli_fetch_assoc($resulti);
				     $sumi = $rowi['value_sum'];
					 
					 echo "There are&nbsp;".$sumi."&nbsp;reservations from<h4>".$email."</h4><br>";
					 
         if($resultCheck > 0){
	         while($row = mysqli_fetch_assoc($result)){
            	 
              
                  
				  echo '<div class="panel-heading"><span class="glyphicon glyphicon-bookmark" aria-hidden="true"></span>&nbsp;'.$row['time']."&nbsp;&nbsp;".
						 '&nbsp;&nbsp;&nbsp;<span class="glyphicon glyphicon-cutlery" aria-hidden="true">You did a reservation</span></div>';
				  
				  //echo '<h5 panel-title ><b><span class="glyphicon glyphicon-tag" aria-hidden="true"></span>&nbsp;'.$row['rname']."&nbsp;&nbsp;&nbsp;";
		        //  echo '<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>&nbsp;'.$row['remail']."&nbsp;&nbsp;&nbsp;";
				//  echo '<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;'.$row['rphone']."</b></h5>&nbsp;&nbsp;&nbsp;";
				  echo '<span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;'.$row['tables']." &nbsp; ";
				   if($row['tables']==1) {
				  echo "table&nbsp;&nbsp;&nbsp;";}
				  else{
				     echo "tables&nbsp;&nbsp;&nbsp;";
				  };
				  echo '<span class="glyphicon glyphicon-user" aria-hidden="true"></span> for &nbsp;'.$row['rnum']." &nbsp;";
				  
				  
				  if($row['rnum']==1) {
				  echo "person&nbsp;&nbsp;";}
				  else{
				     echo "people&nbsp;&nbsp;";
				  };
				  
				  echo '<span class="glyphicon glyphicon-time" aria-hidden="true"></span> on &nbsp;'.$row['rdate']."&nbsp;&nbsp;&nbsp;";
				  echo '<span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;At &nbsp;'.$row['rtime']."&nbsp;&nbsp;&nbsp;<br><br>";
		 		  
			 
                echo "</div>";
				 }
                  }else{
					  echo "There are not reservations";
				  }
						


						
						
						
include "includes/footer.php";
?>

</body>
</html>
