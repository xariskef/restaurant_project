<?php
  include'dbr.php';

$table = $_POST['table'];
$chair = $_POST['chair'];



  $sql = "UPDATE tables SET tables='$table',chairs='$chair' WHERE av_id=1 ;";
 mysqli_query($conn, $sql);


header("Location: ../tables.php?reservation=success");