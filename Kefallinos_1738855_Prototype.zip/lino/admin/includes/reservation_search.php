<?php
  include'dbr.php';

$date = $_GET['date_search'];

if($date==0){
	echo '<script type=\'text/javascript\'>'; 
	echo 'alert("insert a date");';
                             echo "window.location.href='../reservations.php';";
							  echo '</script>';
				  
}

             $date=mysqli_real_escape_string($conn,$date);
             $sql_date = "SELECT COUNT(rid) AS value_sum_date FROM reservation WHERE rdate='$date' ;";
             $result_date = mysqli_query($conn, $sql_date);
             $resultCheck_date = mysqli_num_rows($result_date);
	         $row_date = mysqli_fetch_assoc($result_date);
             $sum_date = $row_date['value_sum_date'];
			

	if($sum_date>0){
	echo '<div><b> There are '.$sum_date.' reservations on '.$date.'</b></div><br>';
	}
	
    $date=mysqli_real_escape_string($conn,$date);
						
					$sql = "SELECT * FROM reservation WHERE rdate='$date';" ;
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
                   
				   
					 
         if($resultCheck > 0){
	         while($row = mysqli_fetch_assoc($result)){
            	 
              
                  
				  echo '<div class="panel panel-default" >';
                  
				  echo '<div>Added on&nbsp;'.$row['time'].
						 '&nbsp;&nbsp;&nbsp;&nbsp;<br></div>&nbsp;'.$row['rname'].'&nbsp;&nbsp;&nbsp;'.$row['remail'].'&nbsp;&nbsp;&nbsp;'.$row['rphone'].'<br>';
				  
				   echo '<span class="glyphicon glyphicon-check" aria-hidden="true"></span>&nbsp;'.$row['tables']." &nbsp; ";
				   if($row['tables']==1) {
				  echo "table&nbsp;&nbsp;&nbsp;";}
				  else{
				     echo "tables&nbsp;&nbsp;&nbsp;";
				  };
				  echo '<span class="glyphicon glyphicon-user" aria-hidden="true"></span> for &nbsp;'.$row['rnum']." &nbsp;";
				  
				  
				  if($row['rnum']==1) {
				  echo "person&nbsp;&nbsp;&nbsp;";}
				  else{
				     echo "people&nbsp;&nbsp;&nbsp;";
				  };
				  
				  echo '<span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;Booked on &nbsp;'.$row['rdate']."&nbsp;&nbsp;&nbsp;";
				  echo '<span class="glyphicon glyphicon-time" aria-hidden="true"></span>&nbsp;At &nbsp;'.$row['rtime']."&nbsp;&nbsp;&nbsp;";
				  echo '<span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;By &nbsp;'.$row['booked_by']."<br><br>";
		 		  
			 
                echo "</div>";
				 }
                  }else{
					  $msg='There are not reservations on '.$date.'';
				/*	  echo ("<script type='JavaScript'>
                                window.alert('".$msg."');
                                window.location.href='../reservation.php';
                           </script>");*/
						    echo '<script type=\'text/javascript\'>'; 
                            echo 'alert("'.$msg.'");'; 
                             echo "window.location.href='../reservations.php';";
							  echo '</script>';
				  }



					 ?>