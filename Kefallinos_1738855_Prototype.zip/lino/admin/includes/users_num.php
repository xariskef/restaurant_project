<?php 
include_once 'dbh.inc.php';

$sql = " SELECT COUNT(DISTINCT idUsers) FROM users;";
$result = mysqli_query($conn, $sql);
$resultCheck = mysqli_num($result);

  if($resultCheck > 0){
	  while($row = mysqli_fetch_assoc($result)){
		  echo $row."<br>";
	  }
  }
