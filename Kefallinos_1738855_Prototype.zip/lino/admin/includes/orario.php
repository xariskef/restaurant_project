<?php
  include'dbr.php';

$monday = $_POST['monday'];
$tuesday = $_POST['tuesday'];
$wednesday = $_POST['wednesday'];
$thursday= $_POST['thursday'];
$friday = $_POST['friday'];
$saturday = $_POST['saturday'];
$sunday = $_POST['sunday'];

$sql = "UPDATE orario SET monday='$monday', tuesday='$tuesday', wednesday='$wednesday', 
  thursday='$thursday', friday='$friday', saturday='$saturday', sunday='$sunday' ;";
 mysqli_query($conn, $sql);


 //$sql = "INSERT INTO orario(monday, tuesday, wednesday, thursday, friday, saturday, sunday)
//  VALUES ('$monday', '$tuesday', '$wednesday', '$thursday', '$friday', '$saturday', '$sunday');";
// mysqli_query($conn, $sql);

header("Location: ../index.php?save=success");