<?php 

// Initialize the session
session_start();
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
	header("location:../error_404/index.html");
							exit();
}
require_once 'includes/dbh.inc.php';
	  require_once "header.php";
?>



  <section id="main">
      <div class="container">
        <div class="row">
   <div class="col-md-3">
            <div class="list-group">
              <a href="index.php" class="list-group-item">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Work Hours
              </a>
              <a href="reservations.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Reservations </a>
              <a href="tables.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Tables </a>
              <a href="costumers.php" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Costumers </a>
            </div>
    </div>
         
          <div class="col-md-9">
	  			 
		    	  <?php
                   $sql = "SELECT * FROM message ORDER BY time DESC;";
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
                   
				   
         if($resultCheck > 0){
	         while($row = mysqli_fetch_assoc($result)){
            	 
                echo '<div class="panel panel-default" >';
                  
				  echo '<div class="panel-heading"><span class="glyphicon glyphicon-bookmark" aria-hidden="true"></span>&nbsp;'.$row['time']."</div>";
				  echo '<h4 panel-title ><span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;'.$row['name']."&nbsp;&nbsp;&nbsp;";
		          echo '<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>&nbsp;'.$row['email']."&nbsp;&nbsp;&nbsp;";
				  echo '<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>&nbsp;'.$row['phone']."</h4>&nbsp;&nbsp;&nbsp;";
		          
				 echo '<div class="panel-body"><p>'.$row['message']."</p></div><br>";		  
		           
				 
                echo "</div>";
				 }
                  }
                  ?>	
		   
		   </div>
		   
        </div>
      </div>
    </section>

    <footer id="footer">
      <nav>Copyright CIKefallinos, &copy; 2019</nav>
    </footer>

 <script>
     CKEDITOR.replace( 'editor1' );
 </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
