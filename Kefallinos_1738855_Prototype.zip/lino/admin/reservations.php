<?php 
// Initialize the session
session_start();
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
	header("location:../error_404/index.html");
							exit();
}
require_once 'includes/dbh.inc.php';
	  require_once "header.php";

?>
    <section id="main">
      <div class="container">
        <div class="row">
 <div class="col-md-3">
            <div class="list-group">
              <a href="index.php" class="list-group-item">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Work Hours
              </a>
              <a href="reservations.php" class="list-group-item active main-color-bg"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Reservations </a>
              <a href="tables.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Tables </a>
              <a href="costumers.php" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Costumers </a>
            </div>
    </div>
  
  
  
  
		 <div class="col-md-9">
             		
  <h3>Make a Reservation</h3>
  <form id="recervation" action="includes/reservation.php" method="post" class="wrap-form-reservation size22 m-l-r-auto">
            <div class="row">
              <div class="col-md-4">
                <!-- Date -->
                <span class="txt9">
                  Date*
                </span>

                <div class="wrap-inputdate pos-relative txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <input class="my-calendar bo-rad-10 sizefull txt10 p-l-20" type="date"  name="date">
                  <i class="btn-calendar fa fa-calendar ab-r-m hov-pointer m-r-18" aria-hidden="true"></i>
                </div>
              </div>

              <div class="col-md-4">
                <!-- Time -->
                <span class="txt9">
                  Time*
                </span>

                <div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <!-- Select2 -->
                  <select class="selection-1" name="time">
                    <option>7:00</option>
                    <option>7:15</option>
                    <option>7:30</option>
                    <option>7:45</option>
                    <option>8:00</option>
                    <option>8:15</option>
                    <option>8:30</option>
                    <option>8:45</option>
                    <option>9:00</option>
                    <option>9:15</option>
                    <option>9:30</option>
                    <option>9:45</option>
                    <option>10:00</option>
                    <option>10:15</option>
                    <option>10:30</option>
                    <option>10:45</option>
                    <option>11:00</option>
                    <option>11:15</option>
                    <option>11:30</option>
                  </select>
                </div>
              </div>

              <div class="col-md-4">
                <!-- People -->
                <span class="txt9">
                  People*
                </span>

                <div class="wrap-inputpeople size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <!-- Select2 -->
                  <select class="selection-1" name="people">
                    <option>1 person</option>
                    <option>2 people</option>
                    <option>3 people</option>
                    <option>4 people</option>
                    <option>5 people</option>
                    <option>6 people</option>
                    <option>7 people</option>
                    <option>8 people</option>
                    <option>9 people</option>
                    <option>10 people</option>
                    <option>11 people</option>
                    <option>12 people</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-4">
                <!-- Name -->
                <span class="txt9">
                  Name*
                </span>

                <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="name" placeholder="Name">
                </div>
              </div>

              <div class="col-md-4">
                <!-- Phone -->
                <span class="txt9">
                  Phone
                </span>

                <div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="phone" placeholder="Phone">
                </div>
              </div>

              <div class="col-md-4">
                <!-- Email -->
                <span class="txt9">
                  Email
                </span>

                <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="email" placeholder="Email">
                </div>
              </div>

            </div>

            <div class="wrap-btn-booking flex-c-m m-t-6">
			
			
			
              <!-- Button3 -->
              <button type="submit" class="btn3 flex-c-m size13 txt11 trans-0-4">
                Book Table
              </button>
            </div>
          </form>
		  <br><br>
		  <h4>Search for reservations per day</h4>
		  <form  action="includes/reservation_search.php" method="GET" >
		  <input type="date" name="date_search">
          <button>Search</button>
           </form>
		   <br>
		  <h4>See the full reservation history</h4>
  <form  action="notifications.php">
  <button>Reservation history</button>
  </form>
 
  
  
  
        </div>
      </div>
    </section>

 <footer id="footer">
      <p>Copyright CIKefallinos, &copy; 2019</p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
