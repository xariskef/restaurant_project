<?php 

// Initialize the session
session_start();
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
	header("location:../error_404/index.html");
							exit();
}


require_once 'includes/dbh.inc.php';
require_once "header.php";
?>
<html>
<body>
  <section id="main">
      <div class="container">
        <div class="row">
   <div class="col-md-3">
            <div class="list-group">
              <a href="index.php" class="list-group-item">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Work Hours
              </a>
              <a href="reservations.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Reservations </a>
              <a href="tables.php" class="list-group-item  active main-color-bg"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Tables </a>
              <a href="costumers.php" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Costumers </a>
            </div>
    </div>
         <div class="col-xs-6 col-sm-3">
		 <h3> Daily details</h3>
 <?php
              
			  $time=date('Y-m-d');
			  $time=mysqli_real_escape_string($conn,$time);
			  
                   $sql = "SELECT SUM(rnum) AS value_sum FROM reservation WHERE rdate='$time' ;";
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
                   
				   
         
	         $row = mysqli_fetch_assoc($result);
            	 $sum_people = $row['value_sum'];
                if($sum_people==0){
					echo "Δέν υπάρχουν κρατήσεις για σήμερα <br>";
				}else{
				
				echo "Σήμερα εχουν κανει κράτηση&nbsp;".$sum_people."&nbsp;άτομα <br>";  
				}
				
				$time=date('Y-m-d');
			  $time=mysqli_real_escape_string($conn,$time);
			  
                   $sql = "SELECT SUM(tables) AS value_sum FROM reservation WHERE rdate='$time' ;";
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
                   
				   
         
	         $row = mysqli_fetch_assoc($result);
            	 $sum = $row['value_sum'];
                if($sum==0){
				    echo "Δέν έχουν κρατηθεί τραπέζια για σήμερα";
				}else{
				echo "Και έχουν κρατηθεί&nbsp;".$sum."&nbsp;τραπέζια";  
				}
                 

                  $sql = "SELECT * FROM tables WHERE av_id=1;";
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
	                $row = mysqli_fetch_assoc($result);
					$tables=$row['tables'];
					$chairs=$row['chairs'];





				 ?>	
</div>
<div class="col-xs-6 col-sm-3">           
              <form id="orario" action="includes/tables.php" method="post" class="wrap-form-reservation size22 m-l-r-auto">   
				 <h3>Set the general  availability</h3>
				 
				 
				 <div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">
                  
               
			    Tables:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="number" value="<?php echo $tables; ?>" name="table"><br>
			    Chairs:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <input type="number" value="<?php echo $chairs; ?>" name="chair"><br>
		    	
			  <button type="submit">
                Save
              </button>
				  
				  
				 </form>
				 
          </div>
		  </div>
		  <div class="col-xs-6 col-sm-3">
                        	<h3>General availability</h3>
                      <?php
                   
            	  echo "Tables:&nbsp;".$tables."<br>";
				 echo "Chairs:&nbsp;".$chairs;
				  	  
		           
                  
                  ?>	

                      </div>
					  
<div class="col-xs-6 col-sm-4">           
              <form id="orario" action="includes/tables_date.php" method="post" class="wrap-form-reservation size22 m-l-r-auto">   
				 <h3>Set the availability by date</h3>
			    <div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">Tables: <input type="number" value="<?php echo $tables; ?>" name="table_day">
			     <div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">Chairs:<input type="number" value="<?php echo $chairs; ?>" name="chair_day"></div>
				 <div class="wrap-inputtime size12 bo2 bo-rad-10 m-t-3 m-b-23">Date:&nbsp&nbsp <input type="date"  name="date"></div><br>
		    	
			  <button type="submit">
                Save
              </button>
				  
				  
				 </form>
				 
         
		
		   
        </div>
      </div>
	  <div class="col-xs-6 col-sm-4">           
              <form id="orario" action="includes/aval_search.php" method="GET" class="wrap-form-reservation size22 m-l-r-auto">   
				 <h3>Search for availability per day</h3>
		  <input type="date" name="date_search">
          <button>Search</button>
           </form>
				  
				  
				 </form>
				 
         
		
		   
        </div>
      </div>
	  <div class="col-xs-6 col-sm-4">           
              
      </div>
    </section>

    <footer id="footer">
      <p>Copyright CIKefallinos, &copy; <?php echo date("Y");?></p>
    </footer>

 <script>
     CKEDITOR.replace( 'editor1' );
 </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
