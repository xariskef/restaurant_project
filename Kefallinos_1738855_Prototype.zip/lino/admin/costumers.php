<?php 

// Initialize the session
session_start();
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
	header("location:../error_404/index.html");
							exit();
}
require_once 'includes/dbh.inc.php';
	  require_once "header.php";
?>
  <section id="main">
      <div class="container">
        <div class="row">

   <div class="col-md-3">
            <div class="list-group">
              <a href="index.php" class="list-group-item">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Dashboard
              </a>
              <a href="reservations.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Reservations </a>
              <a href="tables.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Tables </a>
              <a href="costumers.php" class="list-group-item active main-color-bg"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Costumers </a>
            </div>
    </div>
   
    <div class="col-md-9">           
         <!-- Latest Users -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="panel-title">Latest Users</h3>
                </div>
                <div class="panel-body">
                  <table class="table table-striped table-hover">
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Joined</th>
                      </tr>
					  				
		    	  <?php
                   $sql = "SELECT * FROM users;";
                   $result = mysqli_query($conn, $sql);
                   $resultCheck = mysqli_num_rows($result);
 
         if($resultCheck > 0){
	         while($row = mysqli_fetch_assoc($result)){
            	  echo "<tr><td>".$row['uidUsers']."</td>";
		          echo "<td>".$row['emailUsers']."</td>";
		          echo "<td>".$row['join_date']."</td></tr>";		  
		           }
                  }
                  ?>						
                    
                      
                    </table>
                </div>
              </div>
          </div>
   </div>
   
   
   
   
   
   
   
   
   
   
      </div>
    </section>

    <footer id="footer">
      <p>Copyright CIKefallinos, &copy; 2019</p>
    </footer>
 <script>
     CKEDITOR.replace( 'editor1' );
 </script>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
