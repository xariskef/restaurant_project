<?php
  require_once 'dbr.php';

  $name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];


  $sql = "INSERT INTO message(name, email, phone, message)
    VALUES ('$name', '$email', '$phone', '$message');";
 mysqli_query($conn, $sql);

header("Location: ../contact.php?message=success");
