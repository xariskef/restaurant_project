<?php
  include'dbr.php';

$date = $_POST['date'];
$time = $_POST['time'];
$number = $_POST['people'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$booked_by='Costumer';

if($number <= 4)	{
   $tables=1;
}
elseif(($number > 4) && ($number <= 6)){
	$tables=2;
}elseif(($number > 6) && ($number <= 8)){
	$tables=3;
}elseif(($number > 8) && ($number <= 10)){
	$tables=4;
}elseif(($number > 10) && ($number <= 12)){
	$tables=3;
}
else{
	 $msg="For reservation up to 12 people please make a call reservation";
	echo "<script type=\'text/javascript\'> 
	         alert('$msg');
             location.href='../reservation.php';
		</script>";
				  
 }
           


 if($date==null || $name==null){
	echo '<script type=\'text/javascript\'>'; 
	echo 'alert("insert * values");';
    echo "location.href='../reservation.php';";
							  echo '</script>';
				  
 }
        




                //ζηταμε το αθροισμα των τραπεζιων που εχουν οριστει απο τον διαχειριστη ως διαθεσιμα
				   $sqlt = "SELECT tables FROM tables WHERE av_id=1;";
                   $resultt = mysqli_query($conn, $sqlt);
                 $resultCheckt = mysqli_num_rows($resultt);
	               $rowt = mysqli_fetch_assoc($resultt);
				   $sumt = $rowt['tables'];
				  // echo "number of tables ".$sumt;
				  
				  
				  
				  
                //ζηταμε τα τραπεζια που εχουν οριστικοπιηθει ως διαθεσιμα για την μερα που εγινε η κρατηση
				  $aval_date=mysqli_real_escape_string($conn,$date);
                  $sql_query = "SELECT * FROM tables WHERE date='$aval_date'; ";
                   $result_query = mysqli_query($conn, $sql_query);
                   $resultCheck_result = mysqli_num_rows($result_query);
	               $row_aval = mysqli_fetch_assoc($result_query);
				   $aval_table_date = $row_aval['tables'];
				   if($aval_table_date==0){
					   $aval_table_date=$sumt;
				   }
				 
		

              //ζηταμε το αθροισμα των τραπεζιων που εχουν κρατηθει για την μερα που εγινε η κρατηση
            $rdate=mysqli_real_escape_string($conn,$date);
             $sql_date = "SELECT SUM(tables) AS value_sum_date FROM reservation WHERE rdate='$rdate' ;";
             $result_date = mysqli_query($conn, $sql_date);
             $resultCheck_date = mysqli_num_rows($result_date);
	         $row_date = mysqli_fetch_assoc($result_date);
             $sum_date = $row_date['value_sum_date']; 
			// echo $sum_date;
			 
			 
			 $tables_num=$tables-1;
			 
			 if ($aval_table_date==$sumt){
            // αν τα δεν υπραχουν διαθεσιμα τραπεζια τοτε δεν γινεται η κρατηση
           	  if(($sum_date+$tables_num) >= $sumt){
				  $message="The reservation on ".$date." for ".$tables." table could not been because there are not available tables";
				     echo "<script type='text/javascript'>
					 alert('$message');
                    window.location.href='../reservation.php';
					 </script>";
				  }else{
			 
			 //  echo $sum_date;

  $sql = "INSERT INTO reservation(rdate, rtime, rnum, rname, rphone, remail, tables, booked_by)
    VALUES ('$date', '$time', '$number', '$name', '$phone', '$email', '$tables', '$booked_by');";
 mysqli_query($conn, $sql);

               $message="The reservation on ".$date." for ".$tables." table has been succesfully !!!";
             echo "<script type='text/javascript'>
			         alert('$message');
                     window.location.href='../reservation.php';
				   </script>";

				  }	  
			 }elseif($sumt != $aval_table_date){
				 
				 if(($sum_date+$tables_num)>= $aval_table_date){
					 $message="The reservation on ".$date." for ".$tables." table  could not been because there are not available tables";
				 echo "<script type='text/javascript'>
					alert('$message');
                    window.location.href='../reservation.php';
				 </script>";}
				  else{
					   

  $sql = "INSERT INTO reservation(rdate, rtime, rnum, rname, rphone, remail, tables, booked_by)
    VALUES ('$date', '$time', '$number', '$name', '$phone', '$email', '$tables', '$booked_by');";
 mysqli_query($conn, $sql);
 
  $message="The reservation on ".$date." for ".$tables." table has been succesfully !!!";
             echo "<script type='text/javascript'>
			         alert('$message');
                     window.location.href='../reservation.php';
				   </script>";
					  
				  }
			 }
			 
				   
				   
				   
				   
				  //update to 'user' phone
$phone=mysqli_real_escape_string($conn,$phone);
$email=mysqli_real_escape_string($conn,$email);					
$sql_phone = "UPDATE users SET tel='$phone' WHERE emailUsers='$email' ;";
 mysqli_query($conn, $sql_phone);

?> 
