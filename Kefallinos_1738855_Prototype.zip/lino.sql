-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Φιλοξενητής: 127.0.0.1
-- Χρόνος δημιουργίας: 19 Μάη 2019 στις 15:41:34
-- Έκδοση διακομιστή: 10.1.38-MariaDB
-- Έκδοση PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Βάση δεδομένων: `lino`
--

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `message`
--

CREATE TABLE `message` (
  `name` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `message` text NOT NULL,
  `time` timestamp(1) NOT NULL DEFAULT CURRENT_TIMESTAMP(1)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `message`
--

INSERT INTO `message` (`name`, `email`, `phone`, `message`, `time`) VALUES
('xaris', 'xaris@xaris.com', '6397894567', 'geia sas, pou tha mporousa na steilo viografiko?', '2019-05-14 21:20:18.3');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `orario`
--

CREATE TABLE `orario` (
  `monday` text NOT NULL,
  `tuesday` text NOT NULL,
  `wednesday` text NOT NULL,
  `thursday` text NOT NULL,
  `friday` text NOT NULL,
  `saturday` text NOT NULL,
  `sunday` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `orario`
--

INSERT INTO `orario` (`monday`, `tuesday`, `wednesday`, `thursday`, `friday`, `saturday`, `sunday`) VALUES
('17:00-23:45', '17:00-23:45', '17:00-23:45', '17:00-23:45', '17:00-23:45', '17:00-23:45', '17:00-23:45');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `reservation`
--

CREATE TABLE `reservation` (
  `rid` int(13) NOT NULL,
  `rdate` date NOT NULL,
  `rtime` time NOT NULL,
  `rnum` int(12) NOT NULL,
  `rname` varchar(256) NOT NULL,
  `rphone` text NOT NULL,
  `remail` varchar(256) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tables` int(255) NOT NULL,
  `booked_by` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `reservation`
--

INSERT INTO `reservation` (`rid`, `rdate`, `rtime`, `rnum`, `rname`, `rphone`, `remail`, `time`, `tables`, `booked_by`) VALUES
(320, '2019-05-26', '07:00:00', 1, 'xaris', '6934437016', 'xaris@xaris.com', '2019-05-17 06:21:50', 1, 'Employee'),
(329, '2019-05-17', '07:00:00', 1, 'lalos', '6934437016', 'lalos@lalos.com', '2019-05-17 06:56:04', 1, 'Employee'),
(399, '0000-00-00', '07:00:00', 4, 'lalos', '6934437016', 'lalos@lalos.com', '2019-05-19 12:55:22', 1, 'Costumer'),
(400, '2019-05-31', '07:00:00', 1, 'lalos', '6934437016', 'lalos@lalos.com', '2019-05-19 12:55:29', 1, 'Costumer'),
(401, '2019-08-15', '07:00:00', 7, 'anna', '6934567/89', 'xariskefallnos@gmail.com', '2019-05-19 15:34:43', 3, 'Employee'),
(406, '2019-05-19', '07:00:00', 12, 'xaris', '6932584517', 'xariskefallnos@gmail.com', '2019-05-19 15:49:18', 3, 'Employee');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `tables`
--

CREATE TABLE `tables` (
  `av_id` int(13) NOT NULL,
  `tables` int(255) NOT NULL,
  `chairs` int(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `tables`
--

INSERT INTO `tables` (`av_id`, `tables`, `chairs`, `date`) VALUES
(1, 50, 200, '0000-00-00'),
(47, 100, 400, '2019-08-15'),
(48, 2, 6, '2019-05-22');

-- --------------------------------------------------------

--
-- Δομή πίνακα για τον πίνακα `users`
--

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL,
  `uidUsers` tinytext NOT NULL,
  `emailUsers` tinytext NOT NULL,
  `pwdUsers` longtext NOT NULL,
  `join_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Άδειασμα δεδομένων του πίνακα `users`
--

INSERT INTO `users` (`idUsers`, `uidUsers`, `emailUsers`, `pwdUsers`, `join_date`, `tel`) VALUES
(1, 'lalos', 'lalos@lalos.com', '$2y$10$XzggSNCobeVXKNta5kGJ1.ro8JCy9hx.YkSMdgqkUmS.kTduTUl/m', '2019-05-16 21:46:44', '6934437016'),
(2, 'Anna', 'anna@gmail.com', '$2y$10$Ne3qGEzMEgIRzbOuPK5RBOfgeBl8WwFoKZwJjGonmShdffRrgFlgy', '2019-05-19 12:56:33', '6937545678'),
(3, 'xariskef', 'xarikef@gmail.com', '$2y$10$bvuqSewyTX1NhmhQRZMZUOQLQB0bLvzqL2XisTlmpwK/JJg/QXy4m', '2019-05-19 09:37:00', '');

--
-- Ευρετήρια για άχρηστους πίνακες
--

--
-- Ευρετήρια για πίνακα `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`rid`);

--
-- Ευρετήρια για πίνακα `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`av_id`);

--
-- Ευρετήρια για πίνακα `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsers`);

--
-- AUTO_INCREMENT για άχρηστους πίνακες
--

--
-- AUTO_INCREMENT για πίνακα `reservation`
--
ALTER TABLE `reservation`
  MODIFY `rid` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=414;

--
-- AUTO_INCREMENT για πίνακα `tables`
--
ALTER TABLE `tables`
  MODIFY `av_id` int(13) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT για πίνακα `users`
--
ALTER TABLE `users`
  MODIFY `idUsers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
